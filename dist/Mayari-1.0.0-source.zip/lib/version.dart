const String appVersion = '1.0.0';
const int buildNumber = 1;
const String versionName = 'Initial Release';
String get versionString => '$appVersion (build $buildNumber)';
